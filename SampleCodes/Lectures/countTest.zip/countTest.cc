#include <iostream>

//using namespace std;

int count = 0;

int increase() {
	return ++count;  
}

using namespace std;

int main(int argc, char const *argv[])
{

	cout << increase() << endl;
	cout << increase() << endl;	
	return 0;
}