
extern int num;

int increase() {
	{
	int num1; 

	}
	return ++num;

}

int decrese() {
	return --num;
}